export default function Divider() {
  return <div className="rule" />;
}
