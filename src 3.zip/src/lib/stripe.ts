// src/lib/stripe.ts
import Stripe from "stripe";
import { stripeConfig } from "@/lib/config";

export const stripe = new Stripe(stripeConfig.secretKey, {
  apiVersion: "2024-06-20",
});