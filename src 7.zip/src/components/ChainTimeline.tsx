
"use client";

import { useState } from "react";
import Button from "./Button";

type GenesisProp = {
    id: string;
    issuedAt: string;
    hash: string;
    label: string;
};

type ArtifactProp = {
    id: string;
    issuedAt: string;
    filename: string;
    note: string | null;
    hash: string;
    chainHash: string;
};

export default function ChainTimeline({
    genesis,
    artifacts,
    accessKey
}: {
    genesis: GenesisProp;
    artifacts: ArtifactProp[];
    accessKey: string;
}) {
    // We render a vertical line with nodes.
    // CSS Grid to control layout?

    // Structure:
    // [ TIME ]  ( O )  [ CARD ]

    return (
        <div className="chain-timeline" style={{ position: "relative", paddingLeft: "10px", marginTop: 40, marginBottom: 40 }}>
            {/* The Vertical Line (Faded Gray - Existing) */}
            <div style={{
                position: "absolute",
                left: "29px",
                top: 8,
                bottom: 20,
                width: "2px",
                backgroundColor: "#E0E7FF",
                zIndex: 0
            }}></div>

            {/* BLUE Connector Line (Overlay) */}
            <div style={{
                position: "absolute",
                left: "15px", // Center: 10px padding + 5px radius (Genesis) = 15px.
                top: 11, // Match center of Genesis dot (6px padding + 5px radius)
                bottom: 60,
                width: "1px",
                backgroundColor: "#0000FF",
                zIndex: 0
            }}></div>

            {/* Genesis Node */}
            <div style={{ display: "flex", gap: 24, marginBottom: 40, position: "relative", zIndex: 1 }}>
                {/* Node */}
                <div style={{ paddingTop: 6 }}>
                    <div style={{
                        width: 10, height: 10, borderRadius: "50%", background: "#0000FF",
                        // Removed boxShadow to fix "gap" between line and dot
                    }}></div>
                </div>

                {/* Card */}
                <div style={{ flex: 1 }}>
                    <p className="small" style={{ color: "#666", marginBottom: 4 }}>
                        {new Date(genesis.issuedAt).toUTCString()}
                    </p>
                    <div style={{ border: "1px solid #000", padding: "16px", background: "#fff" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
                            <span style={{ fontWeight: "bold", fontSize: 13, textTransform: "uppercase", letterSpacing: "0.05em" }}>GENESIS RECORD</span>
                            <span className="small-mono" style={{ color: "#888" }}>PAGE 1</span>
                        </div>
                        <h3 className="h3" style={{ fontSize: 18, marginBottom: 12 }}>{genesis.label}</h3>

                        <div style={{ background: "#f5f5f5", padding: "8px 12px", fontSize: 11, fontFamily: "monospace", overflowX: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", border: "1px solid #eee" }}>
                            NONCE: {genesis.hash}
                        </div>
                    </div>
                </div>
            </div>

            {/* Artifacts */}
            {artifacts.map((a, idx) => (
                <div key={a.id} style={{ display: "flex", gap: 24, marginBottom: 40, position: "relative", zIndex: 1 }}>
                    {/* Node */}
                    <div style={{ paddingTop: 6 }}>
                        <div style={{
                            width: 8, height: 8, borderRadius: "50%", background: "#0000FF",
                            marginLeft: 1, // Center relative to 10px genesis: (10-8)/2 = 1.
                            // Removed boxShadow
                        }}></div>
                    </div>

                    {/* Card */}
                    <div style={{ flex: 1 }}>
                        <p className="small" style={{ color: "#666", marginBottom: 4 }}>
                            {new Date(a.issuedAt).toUTCString()}
                        </p>

                        <div style={{ border: "1px solid #e0e0e0", padding: "16px", background: "#fff", transition: "all 0.2s" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
                                <span style={{ fontWeight: "bold", fontSize: 13, textTransform: "uppercase", color: "#444" }}>SEALED ATTACHMENT</span>
                                <span className="small-mono" style={{ color: "#888" }}>PAGE {idx + 2}</span>
                            </div>

                            <h4 style={{ fontSize: 16, marginBottom: 8, fontWeight: 500 }}>{a.filename}</h4>

                            {a.note && (
                                <p style={{ fontSize: 14, fontStyle: "italic", color: "#555", marginBottom: 12, borderLeft: "2px solid #eee", paddingLeft: 8 }}>
                                    “{a.note}”
                                </p>
                            )}

                            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                                <Button size="small" variant="secondary" href={`/vault?id=${a.id}&t=${accessKey}`}>
                                    Preview Original
                                </Button>
                                <Button size="small" variant="secondary" href={`/api/view/${a.id}?t=${accessKey}`}>
                                    Preview & Download Sealed Receipt (PDF)
                                </Button>
                                <span style={{ fontSize: 12, alignSelf: "center", color: '#999', fontFamily: 'monospace' }}>
                                    {a.hash.substring(0, 8)}...
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            ))}

            {/* Pending / Add Node */}
            <div style={{ display: "flex", gap: 24, position: "relative", zIndex: 1 }}>
                <div style={{ paddingTop: 6 }}>
                    <div style={{
                        width: 8, height: 8, borderRadius: "50%", border: "2px solid #ccc", background: "#fff",
                        marginLeft: 1, // Match artifact alignment
                        boxShadow: "0 0 0 4px #fff"
                    }}></div>
                </div>
                <div>
                    <p className="small" style={{ color: "#999", marginBottom: 4 }}>Next Block</p>
                    <div>
                        <Button href={`/success/add-artifact?id=${encodeURIComponent(genesis.id)}&t=${encodeURIComponent(accessKey)}`} variant="primary">
                            + Seal New Page
                        </Button>
                    </div>
                </div>
            </div>

        </div>
    );
}
