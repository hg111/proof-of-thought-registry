export const isTractionUIEnabled = (): boolean => {
    // Hardcoded for production release
    return true;
};
