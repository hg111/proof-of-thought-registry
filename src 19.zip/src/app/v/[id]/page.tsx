'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import '../radiant.css';

export default function RadiantVerifierPage() {
    const params = useParams();
    const [id, setId] = useState<string | null>(null);

    const [record, setRecord] = useState<any>(null);
    const [isRevealed, setIsRevealed] = useState(false);
    const [signals, setSignals] = useState<any[]>([]);
    const [hasLoaded, setHasLoaded] = useState(false);

    // NDA State
    const [ndaRequired, setNdaRequired] = useState(false);
    const [ndaAccepted, setNdaAccepted] = useState(false);
    const [ndaLoading, setNdaLoading] = useState(false);

    // Radio Selection State (Mutually Exclusive)
    const [selectedTier, setSelectedTier] = useState<'pitch' | 'summary' | 'full'>('pitch');

    // Disclosure Request State
    const [requesterEmail, setRequesterEmail] = useState('');
    const [requestLoading, setRequestLoading] = useState(false);
    const [requestSent, setRequestSent] = useState(false);

    useEffect(() => {
        if (params?.id) {
            setId(Array.isArray(params.id) ? params.id[0] : params.id);
        }
    }, [params]);

    useEffect(() => {
        if (!id) return;

        // Check for access token in URL
        const params = new URLSearchParams(window.location.search);
        const token = params.get('access_token');
        const url = `/api/traction/record?record_id=${id}` + (token ? `&access_token=${token}` : '');

        fetch(url)
            .then(res => res.json())
            .then(data => {
                console.log("[DEBUG] API Response:", data);

                // NDA Logic
                if (data.nda_required && !data.nda_accepted) {
                    setNdaRequired(true);
                } else {
                    setNdaRequired(false);
                }

                if (data.revealed) {
                    console.log("[DEBUG] Content Revealed! Setting State.");
                    setIsRevealed(true);
                }
                else console.log("[DEBUG] Content Sealed (Blurred).");

                if (data.record) {
                    setRecord(data.record);
                    return fetch(`/api/traction/signals?record_id=${data.record.id}`);
                }
            })
            .then(res => res?.json())
            .then(data => {
                if (data && data.signals) setSignals(data.signals);
            })
            .catch(console.error)
            .finally(() => setHasLoaded(true));

    }, [id]);

    const handleAcceptNDA = async () => {
        const params = new URLSearchParams(window.location.search);
        const token = params.get('access_token');
        if (!token) return;

        setNdaLoading(true);
        try {
            const res = await fetch('/api/traction/accept-nda', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token })
            });
            if (res.ok) {
                // Reload to fetch content
                window.location.reload();
            } else {
                alert("Failed to accept NDA. Please try again.");
            }
        } catch (e) {
            console.error(e);
            alert("Error connecting to server.");
        } finally {
            setNdaLoading(false);
        }
    };

    if (!hasLoaded || !record) return <div className="radiant-body"><div style={{ opacity: 0.5 }}>Verifying...</div></div>;

    // Real Valuation Logic (Average)
    const realValuation = (() => {
        const parseVal = (b: string) => {
            if (!b) return 0;
            const s = b.toLowerCase().replace(/,/g, '');
            if (s === '$0') return 0;
            if (s.includes('$1–$99')) return 50;
            if (s.includes('$100–$999')) return 500;
            if (s.includes('$1k–')) return 5000;
            if (s.includes('$10k–')) return 55000;
            if (s.includes('$100k–')) return 550000;
            if (s.includes('$1m+')) return 1500000;
            const matches = [...s.matchAll(/(\d+(?:\.\d+)?)\s*([kmb])?/g)];
            if (matches.length === 0) return 0;
            const values = matches.map(m => {
                let val = parseFloat(m[1]);
                const suffix = m[2];
                if (suffix === 'k') val *= 1_000;
                else if (suffix === 'm') val *= 1_000_000;
                else if (suffix === 'b') val *= 1_000_000_000;
                return val;
            });
            const total = values.reduce((acc, v) => acc + v, 0);
            return Math.round(total / values.length);
        };

        const vals = signals
            .filter(s => s.type === 'ack_value' && (s.val_bucket || s.val_exact))
            .map(s => parseVal(s.val_exact || s.val_bucket));

        if (vals.length === 0) return "—";

        const total = vals.reduce((acc, v) => acc + v, 0);
        const avg = total / vals.length;

        return avg >= 1000000
            ? `$${(avg / 1000000).toFixed(1)}M`
            : avg >= 1000
                ? `$${(avg / 1000).toFixed(0)}K`
                : `$${avg.toFixed(0)}`;
    })();

    // Tier Labels Mapping
    const tierLabels = {
        pitch: "Elevator Pitch (1-pager)",
        summary: "Executive Summary (Deck)",
        full: "Full Disclosure (Data Room)"
    };

    return (
        <div className="radiant-body">

            <div className="radiant-layout-row">

                {/* 1. SIDE TITLE */}
                <div className="radiant-title-col">
                    {(() => {
                        const originalTitle = record.title || "Untitled Record";
                        const allWords = originalTitle.replace(/-/g, ' ').split(/\s+/).filter(Boolean);
                        const MAX_WORDS = 16;
                        const isTruncated = allWords.length > MAX_WORDS;
                        const displayWords = isTruncated ? [...allWords.slice(0, MAX_WORDS), "..."] : allWords;
                        let fontSize = '48px';
                        const count = displayWords.length;
                        if (count > 12) fontSize = '32px';
                        else if (count > 8) fontSize = '40px';

                        return displayWords.map((word: string, i: number) => (
                            <div key={i} className="radiant-vertical-word" style={{ fontSize }}>{word}</div>
                        ));
                    })()}
                </div>

                {/* 2. PROOF PANEL / CONTENT */}
                {(() => {
                    // Logic: 
                    // 1. If NDA Required -> Show NDA Gate
                    // 2. If Revealed -> Show Content
                    // 3. Else -> Show Sealed Cert

                    if (ndaRequired) {
                        return (
                            <div className="radiant-box radiant-box-proof" style={{ border: '1px solid #eab308' }}>
                                <div className="radiant-proof-header" style={{ borderColor: '#eab308' }}>
                                    <div className="radiant-kicker" style={{ color: '#fde047' }}>Confidentiality Agreement</div>
                                    <h2 className="radiant-h2">NDA Required</h2>
                                </div>
                                <div className="radiant-content">
                                    <div style={{ marginBottom: '16px', fontSize: '13px', opacity: 0.8 }}>
                                        To view this full disclosure, you must agree to the following Non-Disclosure Agreement:
                                    </div>
                                    <div style={{
                                        background: 'rgba(0,0,0,0.3)',
                                        padding: '16px',
                                        borderRadius: '8px',
                                        fontSize: '12px',
                                        maxHeight: '200px',
                                        overflowY: 'auto',
                                        marginBottom: '24px',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        whiteSpace: 'pre-wrap',
                                        fontFamily: 'monospace'
                                    }}>
                                        {record.nda_text || "This information is confidential. By proceeding, you agree not to share or reproduce this content without permission."}
                                    </div>
                                    <button
                                        className="radiant-btn"
                                        style={{ width: '100%', justifyContent: 'center', background: '#eab308', color: '#000', fontWeight: 600 }}
                                        onClick={handleAcceptNDA}
                                        disabled={ndaLoading}
                                    >
                                        {ndaLoading ? "Accepting..." : "I Agree & Enter"}
                                    </button>
                                </div>
                            </div>
                        );
                    }

                    // REVEAL LOGIC
                    // We might show Pitch/Summary even if "Full" is sealed.
                    const showPitch = !!record.pitch_text;
                    const showSummary = !!record.summary_text; // TODO: Should this check token scope? 
                    // For now, if you are past NDA, you see Summary if it exists.
                    // Actually, if 'isRevealed' is FALSE, it means we don't have FULL access.
                    // But we might have SUMMARY access.

                    // Since 'isRevealed' (Full Content) comes from backend only if authorized,
                    // we can rely on that for the "Sealed/Unsealed" Proof State.

                    return (
                        <div className={`radiant-box radiant-box-proof ${isRevealed ? 'unsealed' : ''}`} style={{ border: isRevealed ? '1px solid #22c55e' : '1px solid rgba(255,255,255,0.1)' }}>
                            <div className="radiant-proof-header" style={{ borderColor: isRevealed ? '#22c55e' : 'rgba(255,255,255,0.1)', position: 'relative' }}>
                                {isRevealed && (
                                    <div style={{
                                        position: 'absolute',
                                        top: '32px',
                                        right: '32px',
                                        fontSize: '13px',
                                        color: '#22c55e',
                                        fontWeight: 600,
                                        letterSpacing: '0.5px'
                                    }}>
                                        DISCLOSURE ACTIVE
                                    </div>
                                )}
                                {!isRevealed && (
                                    <div style={{
                                        position: 'absolute',
                                        top: '32px',
                                        right: '32px',
                                        fontSize: '13px',
                                        fontWeight: 500,
                                        color: 'rgba(255,255,255,0.5)',
                                        letterSpacing: '0.5px'
                                    }}>
                                        PROOF OF THOUGHT™
                                    </div>
                                )}
                                <div className="radiant-kicker" style={{ color: isRevealed ? '#4ade80' : '#94a3b8' }}>
                                    {isRevealed ? "Authenticated Access" : "Genesis Record"}
                                </div>
                                <h2 className="radiant-h2">
                                    {isRevealed ? "Full Content Revealed" : "Cryptographic Proof"}
                                </h2>
                            </div>

                            <div className="radiant-content" style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: '24px' }}>

                                {/* 1. MUTABLE PACKAGING (Pitch/Summary) */}
                                {(showPitch || showSummary) && (
                                    <div style={{ paddingBottom: '24px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                                        {showPitch && (
                                            <div style={{ marginBottom: '20px' }}>
                                                <div className="radiant-field-lbl" style={{ color: '#60a5fa', marginBottom: '8px' }}>ELEVATOR PITCH</div>
                                                <div style={{ fontSize: '16px', lineHeight: '1.5', fontWeight: 400, color: '#fff' }}>
                                                    {record.pitch_text}
                                                </div>
                                            </div>
                                        )}
                                        {showSummary && (
                                            <div>
                                                <div className="radiant-field-lbl" style={{ color: '#fde047', marginBottom: '8px' }}>EXECUTIVE SUMMARY</div>
                                                <div style={{
                                                    fontSize: '14px',
                                                    lineHeight: '1.6',
                                                    color: 'rgba(255,255,255,0.9)',
                                                    whiteSpace: 'pre-wrap',
                                                    fontFamily: 'monospace',
                                                    background: 'rgba(255,255,255,0.03)',
                                                    padding: '16px',
                                                    borderRadius: '6px'
                                                }}>
                                                    {record.summary_text}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {/* 2. IMMUTABLE PROOF (Full/Sealed) */}
                                {isRevealed ? (
                                    <div style={{
                                        flex: 1,
                                        overflowY: 'auto',
                                        minHeight: '200px', // Ensure it has presence
                                        whiteSpace: 'pre-wrap',
                                        fontFamily: 'monospace',
                                        fontSize: '13px',
                                        lineHeight: '1.6',
                                        color: '#fff',
                                        paddingRight: '12px',
                                        paddingBottom: '20px'
                                    }}>
                                        <div className="radiant-field-lbl" style={{ color: '#22c55e', marginBottom: '12px' }}>CANONICAL PROOF (IMMUTABLE)</div>
                                        {record.canonical_text}
                                        <div style={{ marginTop: '24px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.1)', fontSize: '11px', opacity: 0.5 }}>
                                            Audit Log: This view has been cryptographically recorded.
                                        </div>
                                    </div>
                                ) : (
                                    // SEALED VIEW
                                    <div>
                                        <div style={{ display: 'grid', gap: '16px', marginBottom: '24px' }}>
                                            <div>
                                                <div className="radiant-field-lbl">Registry No</div>
                                                <div className="radiant-field-val">{record.registry_no ? `R-${String(record.registry_no).padStart(16, '0')}` : "R-..."}</div>
                                            </div>
                                            <div>
                                                <div className="radiant-field-lbl">Timestamp (UTC)</div>
                                                <div className="radiant-field-val">
                                                    {new Date(record.created_at).toISOString().replace('T', ' ').split('.')[0]} UTC
                                                </div>
                                            </div>
                                            <div>
                                                <div className="radiant-field-lbl">Content Hash (SHA-256)</div>
                                                <div className="radiant-field-val">{record.content_hash}</div>
                                            </div>
                                        </div>

                                        <div className="radiant-blurred-block">
                                            <div className="radiant-lock-overlay">
                                                <span>🔒</span> Sealed Content (Encrypted)
                                            </div>
                                            <div className="radiant-blur-line" style={{ width: '90%' }}></div>
                                            <div className="radiant-blur-line" style={{ width: '95%' }}></div>
                                            <div className="radiant-blur-line" style={{ width: '80%' }}></div>
                                            <div className="radiant-blur-line" style={{ width: '85%' }}></div>
                                        </div>

                                        <div style={{ marginTop: '24px', opacity: 0.5, fontSize: '11px', lineHeight: '1.5' }}>
                                            This certificate proves that the information existed in this form at the timestamped date.
                                        </div>
                                    </div>
                                )}

                            </div>
                        </div>
                    );
                })()}

                {/* 3. TRACTION PANEL */}
                <div className="radiant-box radiant-box-traction">
                    <div className="radiant-proof-header" style={{ borderColor: '#1e3a8a' }}>
                        <div className="radiant-kicker" style={{ color: '#60a5fa' }}>Market Signal</div>
                        <h2 className="radiant-h2">Traction</h2>
                    </div>
                    <div className="radiant-traction-hero">

                        {/* Metrics Row */}
                        <div style={{ display: 'flex', gap: '32px', marginBottom: '8px', alignItems: 'flex-end' }}>
                            <div style={{ textAlign: 'center' }}>
                                <div className="radiant-fraction">
                                    <span className="num">{signals.length}</span>
                                </div>
                                <div style={{ fontSize: '10px', color: '#64748b', textTransform: 'uppercase', marginTop: '4px' }}>Signals</div>
                            </div>
                            <div style={{ width: '1px', height: '40px', background: 'rgba(255,255,255,0.1)' }}></div>
                            <div style={{ textAlign: 'center' }}>
                                <div className="radiant-fraction">
                                    <span className="num">{Math.min(100, signals.reduce((acc, s) => acc + 1 + (s.type === 'ack_value' ? 4 : 0), 0))}</span>
                                    <span className="denom">/100</span>
                                </div>
                                <div style={{ fontSize: '10px', color: '#64748b', textTransform: 'uppercase', marginTop: '4px' }}>Score</div>
                            </div>
                        </div>

                        <div className="radiant-val-lbl">Current Valuation</div>
                        <div className="radiant-big-val">{realValuation}</div>

                        {/* Panel CTA Login: If NDA Required, hide request form (because they already have a token, just locked) */}
                        {/* Actually, if they are here with a token, they can accept NDA. */}
                        {/* If they are here WITHOUT a token (public), they see Request Form. */}

                        {(isRevealed || record.canonical_text || ndaRequired) ? ( // ndaRequired means they have token
                            <div style={{ marginTop: '24px', textAlign: 'center' }}>
                                {ndaRequired ? (
                                    <div style={{ marginBottom: '16px', padding: '12px', background: 'rgba(234, 179, 8, 0.1)', border: '1px solid rgba(234, 179, 8, 0.3)', borderRadius: '8px' }}>
                                        <div style={{ fontSize: '14px', fontWeight: 600, color: '#fde047', marginBottom: '4px' }}>⚠ Action Required</div>
                                        <div style={{ fontSize: '12px', opacity: 0.7 }}>Accept NDA to view.</div>
                                    </div>
                                ) : (
                                    <div style={{ marginBottom: '16px', padding: '12px', background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.3)', borderRadius: '8px' }}>
                                        <div style={{ fontSize: '14px', fontWeight: 600, color: '#4ade80', marginBottom: '4px' }}>✓ Verified Viewer</div>
                                        <div style={{ fontSize: '12px', opacity: 0.7 }}>You have full access to this record.</div>
                                    </div>
                                )}

                                <button
                                    className="radiant-btn"
                                    onClick={() => window.location.href = `mailto:?subject=Regarding: ${record.title}&body=I have reviewed your disclosed Proof-of-Thought.`}
                                >
                                    Contact Creator
                                </button>
                            </div>
                        ) : (
                            <>
                                <div className="radiant-tier-list">
                                    <div className="radiant-tier-item" onClick={() => setSelectedTier('pitch')}>
                                        <div className={`radiant-checkbox round ${selectedTier === 'pitch' ? 'checked' : ''}`}>
                                            {selectedTier === 'pitch' && <div className="radiant-dot-inner"></div>}
                                        </div>
                                        <span>{tierLabels.pitch}</span>
                                    </div>

                                    <div className="radiant-tier-item" onClick={() => setSelectedTier('summary')}>
                                        <div className={`radiant-checkbox round ${selectedTier === 'summary' ? 'checked' : ''}`}>
                                            {selectedTier === 'summary' && <div className="radiant-dot-inner"></div>}
                                        </div>
                                        <span>{tierLabels.summary}</span>
                                    </div>

                                    <div className="radiant-tier-item" onClick={() => setSelectedTier('full')}>
                                        <div className={`radiant-checkbox round ${selectedTier === 'full' ? 'checked' : ''}`}>
                                            {selectedTier === 'full' && <div className="radiant-dot-inner"></div>}
                                        </div>
                                        <span className={selectedTier === 'full' ? 'radiant-highlight-text' : ''}>{tierLabels.full}</span>
                                    </div>
                                </div>

                                <div style={{ marginTop: '12px' }}>
                                    {!requestSent ? (
                                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                            <input
                                                type="email"
                                                placeholder="Enter your email to request access..."
                                                className="radiant-input"
                                                style={{
                                                    background: 'rgba(255,255,255,0.05)',
                                                    border: '1px solid rgba(255,255,255,0.1)',
                                                    color: '#fff',
                                                    padding: '6px 10px',
                                                    borderRadius: '6px',
                                                    fontSize: '12px'
                                                }}
                                                value={requesterEmail}
                                                onChange={e => setRequesterEmail(e.target.value)}
                                            />
                                            <button
                                                className="radiant-btn"
                                                disabled={requestLoading}
                                                onClick={async () => {
                                                    if (!requesterEmail.includes('@')) {
                                                        alert("Please enter a valid email.");
                                                        return;
                                                    }
                                                    setRequestLoading(true);
                                                    try {
                                                        const res = await fetch('/api/traction/request-disclosure', {
                                                            method: 'POST',
                                                            headers: { 'Content-Type': 'application/json' },
                                                            body: JSON.stringify({
                                                                record_id: record.id,
                                                                requester_email: requesterEmail,
                                                                request_type: tierLabels[selectedTier]
                                                            })
                                                        });
                                                        if (res.ok) {
                                                            setRequestSent(true);
                                                        } else {
                                                            alert("Use default mail client? API failed.");
                                                            window.location.href = `mailto:?subject=Request Access&body=Requesting ${tierLabels[selectedTier]}`;
                                                        }
                                                    } catch (e) {
                                                        console.error(e);
                                                        alert("Error sending request.");
                                                    } finally {
                                                        setRequestLoading(false);
                                                    }
                                                }}
                                            >
                                                {requestLoading ? 'Sending...' : 'Request Disclosure'}
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="radiant-success-msg" style={{ padding: '15px', background: 'rgba(50, 205, 50, 0.1)', border: '1px solid rgba(50, 205, 50, 0.3)', borderRadius: '8px', textAlign: 'center' }}>
                                            <div style={{ fontSize: '18px', marginBottom: '4px' }}>✓ Request Sent</div>
                                            <div style={{ fontSize: '13px', opacity: 0.8 }}>The owner has been notified. Check your email ({requesterEmail}).</div>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                </div>

            </div>

        </div>
    );
}
