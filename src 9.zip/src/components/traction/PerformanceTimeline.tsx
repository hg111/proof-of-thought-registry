'use client';

import React, { useEffect, useRef, useState } from 'react';
import '../../app/traction/traction.css';

// --- Types ---
type EventType = 'sealed' | 'invite' | 'ack' | 'val';

interface TimelineEvent {
    type: EventType;
    label: string;
    at: Date;
}

// --- Helpers ---
function addMonths(date: Date, n: number): Date {
    const d = new Date(date);
    const day = d.getDate();
    d.setMonth(d.getMonth() + n);
    if (d.getDate() < day) d.setDate(0);
    return d;
}

function clamp(n: number, a: number, b: number): number {
    return Math.max(a, Math.min(b, n));
}

function pctBetween(date: Date, min: Date, max: Date): number {
    const t = date.getTime();
    const a = min.getTime();
    const b = max.getTime();
    const span = Math.max(1, b - a);
    return ((t - a) / span) * 100;
}

// Format helpers
const fmtMonth = (d: Date) => d.toLocaleString("en-US", { month: "short" });
// const fmtDateTime = (d: Date) => {
//   const m = d.toLocaleString("en-US", { month: "short" });
//   const day = d.getDate();
//   const hh = String(d.getHours()).padStart(2, "0");
//   const mm = String(d.getMinutes()).padStart(2, "0");
//   return `${m} ${day} • ${hh}:${mm}`;
// }

// --- Config ---
const HORIZON_MONTHS = 12;
const START_ISO = "2026-01-13T13:08:00-08:00"; // sealed time (mock)
const SAFE_GUTTER_PX = 22;

// --- Mock Data Generator ---
function generateMockEventsWeekly(sealedAt: Date): TimelineEvent[] {
    const t0 = sealedAt.getTime();
    const H = 60 * 60 * 1000;
    const D = 24 * H;
    return [
        { type: "sealed", label: "Sealed", at: new Date(t0) },
        { type: "invite", label: "Invites", at: new Date(t0 + 2.4 * H) },   // same day
        { type: "ack", label: "Ack", at: new Date(t0 + 1.9 * D) },   // day ~2
        { type: "val", label: "Valuation", at: new Date(t0 + 3.2 * D) },   // day ~3
        { type: "ack", label: "Ack", at: new Date(t0 + 4.6 * D) },   // day ~5
        { type: "val", label: "Valuation", at: new Date(t0 + 6.0 * D) },   // day ~7
    ];
}

const baseStart = new Date(START_ISO);
const baseEnd = addMonths(baseStart, HORIZON_MONTHS);
const baseSpanMs = Math.max(1, baseEnd.getTime() - baseStart.getTime());
const mockEvents = generateMockEventsWeekly(baseStart);


export default function PerformanceTimeline() {
    const containerRef = useRef<HTMLDivElement>(null);
    const rulerRef = useRef<HTMLDivElement>(null);
    const trackRef = useRef<HTMLDivElement>(null);

    // State for zoom/pan
    const [zoom, setZoom] = useState(1);
    const [panPx, setPanPx] = useState(0);

    // We use refs for mutable state during drag to avoid re-renders on every pixel move if possible,
    // or just to keep track of drag start positions.
    const dragState = useRef({
        isDragging: false,
        startX: 0,
        startPan: 0,
    });

    // Re-render ruler on zoom/pan/resize
    useEffect(() => {
        const rulerEl = rulerRef.current;
        if (!rulerEl) return;

        const render = () => {
            // Clear track
            if (trackRef.current) {
                trackRef.current.innerHTML = '';
            } else {
                return; // Should exist
            }
            const track = trackRef.current;

            const inset = 28;
            const w = rulerEl.clientWidth;
            const usable = Math.max(1, w - inset * 2);

            // Compute Domain
            const MIN_SPAN_MS = 6 * 60 * 60 * 1000;
            const MAX_SPAN_MS = baseSpanMs;
            const visibleSpanMs = clamp(baseSpanMs / zoom, MIN_SPAN_MS, MAX_SPAN_MS);

            // Pan logic
            // panPx is clamped in render, but efficient state update might be needed
            // Actually we just use the prop values here
            // Enforce pan bounds
            const effectivePanPx = clamp(panPx, 0, usable);
            const panFrac = usable <= 1 ? 0 : (effectivePanPx / usable);
            const centerMs = baseStart.getTime() + panFrac * baseSpanMs;

            let domainStart = new Date(centerMs - visibleSpanMs / 2);
            let domainEnd = new Date(centerMs + visibleSpanMs / 2);

            if (domainStart < baseStart) {
                domainStart = new Date(baseStart);
                domainEnd = new Date(baseStart.getTime() + visibleSpanMs);
            }
            if (domainEnd > baseEnd) {
                domainEnd = new Date(baseEnd);
                domainStart = new Date(baseEnd.getTime() - visibleSpanMs);
            }

            // Render helpers
            const innerW = Math.max(1, usable - SAFE_GUTTER_PX * 2);
            const toX = (pct: number) => SAFE_GUTTER_PX + innerW * (pct / 100);

            // 1. Horizon Line
            const line = document.createElement("div");
            Object.assign(line.style, {
                position: "absolute",
                left: "0px",
                right: "0px",
                top: "44px",
                height: "2px",
                background: "rgba(255,255,255,.16)"
            });
            track.appendChild(line);

            // 2. Minor Ticks
            const spanDays = visibleSpanMs / (24 * 60 * 60 * 1000);
            const useDays = spanDays <= 60;

            if (!useDays) {
                // Months
                for (let i = 0; i <= HORIZON_MONTHS; i++) {
                    const d = addMonths(baseStart, i);
                    const pct = pctBetween(d, domainStart, domainEnd);
                    if (pct < 0 || pct > 100) continue;

                    const isQuarter = (i % 3 === 0);
                    const showLabel = (i === 0) || (i === HORIZON_MONTHS) || isQuarter;

                    const t = document.createElement("div");
                    t.className = "traction-minorTick" + (isQuarter ? " q" : "");
                    t.style.left = `${toX(pct)}px`;
                    t.innerHTML = `
            <div class="mStem"></div>
            <div class="mLab">${showLabel ? fmtMonth(d) : ""}</div>
          `;
                    track.appendChild(t);
                }
            } else {
                // Days
                const dayMs = 24 * 60 * 60 * 1000;
                const first = new Date(domainStart); first.setHours(0, 0, 0, 0);
                const last = new Date(domainEnd); last.setHours(0, 0, 0, 0);

                let idx = 0;
                for (let tMs = first.getTime(); tMs <= last.getTime(); tMs += dayMs) {
                    const d = new Date(tMs);
                    const pct = pctBetween(d, domainStart, domainEnd);
                    if (pct < 0 || pct > 100) continue;

                    const tick = document.createElement("div");
                    tick.className = "traction-minorTick";
                    tick.style.left = `${toX(pct)}px`;

                    const labelEvery = spanDays <= 14 ? 1 : 2;
                    const showLabel = (idx % labelEvery === 0) || (tMs === first.getTime()) || (tMs === last.getTime());

                    tick.innerHTML = `
            <div class="mStem"></div>
            <div class="mLab">${showLabel ? d.toLocaleString("en-US", { month: "short", day: "numeric" }) : ""}</div>
          `;
                    track.appendChild(tick);
                    idx++;
                }
            }

            // 3. Events & Stacking
            const minDx = spanDays <= 14 ? 90 : 60;
            // Simple greedy lane assignment
            // stored as { endX, laneIndex }
            const lanes: number[] = [];

            // Sort events by time just in case
            const sortedEvents = [...mockEvents].sort((a, b) => a.at.getTime() - b.at.getTime());

            sortedEvents.forEach(ev => {
                const pct = pctBetween(ev.at, domainStart, domainEnd);
                if (pct < -5 || pct > 105) return; // allow slight overscan

                const x = toX(pct);

                // Find lane
                let lane = 0;
                let placed = false;
                // events are approximately 100-150px wide visually, but we use minDx for spacing
                // We'll just check against the last item in each lane
                for (let l = 0; l < lanes.length; l++) {
                    if (x > lanes[l] + minDx) {
                        lanes[l] = x;
                        lane = l;
                        placed = true;
                        break;
                    }
                }
                if (!placed) {
                    lane = lanes.length;
                    lanes.push(x);
                }

                const el = document.createElement("div");
                // class mapping
                let typeClass = "";
                if (ev.type === 'ack') typeClass = " ack";
                if (ev.type === 'val') typeClass = " val";

                el.className = `traction-tick${typeClass}`;
                el.style.left = `${x}px`;
                el.style.setProperty('--lane', String(lane));
                el.innerHTML = `
            <div class="stem"></div>
            <div class="dot"></div>
            <div class="type">${ev.type === 'sealed' ? 'Sealed' : ev.type === 'val' ? 'Valuation' : ev.type === 'ack' ? 'Acknowledgement' : ev.label}</div>
            <div class="lab">${ev.at.toLocaleString("en-US", { hour: 'numeric', minute: 'numeric', hour12: false })}</div>
        `;
                track.appendChild(el);
            });
        };

        render();

        // Resize observer to re-render on size change
        const ro = new ResizeObserver(render);
        ro.observe(rulerEl);
        return () => ro.disconnect();

    }, [zoom, panPx]);


    // Event Handlers
    const handleWheel = (e: React.WheelEvent) => {
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            const ZOOM_SPEED = 0.0015;
            const dy = -e.deltaY;
            const factor = Math.exp(dy * ZOOM_SPEED);
            setZoom(z => clamp(z * factor, 1, 80));
        }
    };

    const handlePointerDown = (e: React.PointerEvent) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragState.current = {
            isDragging: true,
            startX: e.clientX,
            startPan: panPx,
        };
        if (rulerRef.current) rulerRef.current.style.cursor = 'grabbing';
    };

    const handlePointerMove = (e: React.PointerEvent) => {
        if (!dragState.current.isDragging) return;
        const dx = e.clientX - dragState.current.startX;
        // Pan moves opposite to drag? No, drag left = move viewport right = pan increase?
        // Prototype: "drag-to-pan". Usually dragging content right means moving view left (time decreases --> earlier).
        // Let's assume standard direct manip: drag right -> events move right -> view moves left -> panPx decreases?
        // Implementation in prototype is not fully visible, but let's try direct mapping.
        // If I map panPx to centerMs... 
        // centerMs = start + (panPx / usable) * total.
        // increasing panPx moves center to later time.
        // Dragging RIGHT should show EARLIER time (move content right). So panPx should DECREASE.

        // Scale factor needs to relate pixels to panPx
        // panPx is in pixels relative to "usable width".
        // 1px of drag should ideally correspond to 1px of pan if zoom is 1?
        // Let's just apply -dx to panPx.

        // Adjust sensitivity based on zoom to feel natural?
        // Actually, simple 1-to-1 pixel dragging matches the cursor best.

        const w = rulerRef.current?.clientWidth || 1000;
        // If I drag 100px right, I want the point under cursor to stay under cursor.
        // For now, simple linear shift.

        const newPan = dragState.current.startPan - dx; // Inverted
        setPanPx(newPan);
    };

    const handlePointerUp = (e: React.PointerEvent) => {
        dragState.current.isDragging = false;
        e.currentTarget.releasePointerCapture(e.pointerId);
        if (rulerRef.current) rulerRef.current.style.cursor = 'grab';
    };


    return (
        <div className="traction-card">
            <div className="traction-pad">
                <div className="traction-rulerTop">
                    <div className="traction-kicker">Traction timeline</div>
                    <div className="traction-sub traction-micro" style={{ margin: 0 }}>First tick = sealed. New ticks = ack/valuation events.</div>
                </div>

                <div
                    className="traction-rulerLine"
                    id="ruler"
                    ref={rulerRef}
                    onWheel={handleWheel}
                    onPointerDown={handlePointerDown}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerLeave={handlePointerUp}
                >
                    <div className="traction-rulerTrack" ref={trackRef}></div>
                </div>

                <div className="traction-foot traction-micro" style={{ marginTop: '10px' }}>
                    Horizon shows month marks; events stack automatically when close together.
                    (Scroll/Trackpad to zoom, Drag to pan)
                </div>
            </div>
        </div>
    );
}
