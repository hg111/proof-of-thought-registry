import { PDFDocument } from "pdf-lib";

function fmtUtc(isoUtc: string) {
  const s = String(isoUtc || "").trim();
  if (!s) return "—";

  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;

  const pad = (n: number) => String(n).padStart(2, "0");
  const yyyy = d.getUTCFullYear();
  const mm = pad(d.getUTCMonth() + 1);
  const dd = pad(d.getUTCDate());
  const hh = pad(d.getUTCHours());
  const mi = pad(d.getUTCMinutes());
  const ss = pad(d.getUTCSeconds());
  return `${yyyy}.${mm}.${dd} • ${hh}:${mi}:${ss} UTC`;
}

export async function buildArtifactPdf(args: {
  parentId: string;
  artifactId: string;
  issuedAtUtc: string;
  filename: string;
  canonicalHash: string;
  chainHash: string;
  verifyUrl: string;
  imageBytes?: Uint8Array;
  imageMime?: string;
}) {
  if (!args.imageBytes || args.imageBytes.length === 0) {
    throw new Error("artifactPdf: missing imageBytes");
  }

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const { height } = page.getSize();

  const draw = (t: string, x = 54, y = 0, s = 10) =>
    page.drawText(t, { x, y, size: s });

  let y = height - 54;
  draw("PROOF OF THOUGHT™", 54, y, 14); y -= 26;
  draw("Sealed Artifact Receipt", 54, y, 12); y -= 20;

  const block = (k: string, v: string) => {
    draw(k, 54, y, 9); y -= 14;
    draw(v, 54, y, 10); y -= 22;
  };

  block("PARENT CERTIFICATE", args.parentId);
  block("ARTIFACT ID", args.artifactId);
  block("ISSUED AT (UTC)", fmtUtc(args.issuedAtUtc));   // ✅ prints 2026.01.04 • 19:42:37 UTC
  block("FILENAME", args.filename);
  block("HASH (SHA-256)", args.canonicalHash);
  block("CHAIN HASH", args.chainHash);
  block("VERIFY", args.verifyUrl);

  // --- EMBED IMAGE PREVIEW ---
  const mime = (args.imageMime || "").toLowerCase();
  const isPng =
    mime.includes("png") || args.filename.toLowerCase().endsWith(".png");

  const embedded = isPng
    ? await pdf.embedPng(args.imageBytes)
    : await pdf.embedJpg(args.imageBytes);

  // Fit into a nice box
  const maxW = 612 - 54 * 2; // 504
  const maxH = 300;

  const dims = embedded.scale(1);
  const scale = Math.min(maxW / dims.width, maxH / dims.height, 1);

  const w = dims.width * scale;
  const h = dims.height * scale;

  const xImg = 54;
  const yImg = 80; // fixed safe area near bottom

  draw("ARTIFACT PREVIEW", 54, yImg + h + 10, 9);
  page.drawImage(embedded, { x: xImg, y: yImg, width: w, height: h });

  const bytes = await pdf.save();
  return Buffer.from(bytes);
}